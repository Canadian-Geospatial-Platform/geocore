import { DynamoDBClient, PutItemCommand } from "@aws-sdk/client-dynamodb";
import { CodeBuildClient, StartBuildCommand } from "@aws-sdk/client-codebuild";
import https from "https";
import url from "url";

const codebuild = new CodeBuildClient();
const dynamodb = new DynamoDBClient({});

const codebuildProjectName = process.env.PROCESS_CODEBUILD_NAME;

export const handler = async (event, context) => {

  console.log("Event:", JSON.stringify(event, null, 2));
  console.log(`codebuildProjectName: ${codebuildProjectName}`);

  const responseData = {};
  const physicalResourceId = event.PhysicalResourceId || `custom-resource-${event.RequestId}`;
  
  try {
    const requestType = event.RequestType;
    const properties = event.ResourceProperties;
  
    { // Build docker
      if (requestType === "Create" || requestType === "Update") {
        const params = {
          projectName: codebuildProjectName,
          environmentVariablesOverride: [
            { name: 'GITHUB_REPO', value: properties.DockerGithubRepo, type: 'PLAINTEXT' },
            { name: 'GITHUB_BRANCH', value: properties.DockerGithubBranch, type: 'PLAINTEXT' },
            { name: 'ECR_REPO_URI', value: properties.DockerEcrRepo, type: 'PLAINTEXT' },
            { name: 'IMAGE_TAG', value: properties.DockerImageTag, type: 'PLAINTEXT' }
          ]
        };
    
        const result = await codebuild.send(new StartBuildCommand(params));
        console.log('Build started:', result);
      } else {
        console.log("Delete request - no action taken.");
      }
    }

    { // Insert Item into DynamoDB
      const item = JSON.parse(properties.ItemToUpsert);
      const tableName = properties.ProcessesTableName;
      
      if (requestType === "Create" || requestType === "Update") {
        await dynamodb.send(new PutItemCommand({
          TableName: tableName,
          Item: item,
        }));
        
        console.log(`Upserted item into ${tableName}`);
      } else {
        console.log("Delete request - no action taken.");
      }
    }

    await sendResponse(event, context, "SUCCESS", responseData, physicalResourceId);
  } catch (error) {
    console.error("Error:", error);
    await sendResponse(event, context, "FAILED", { Error: error.message }, physicalResourceId);
  }
};

async function sendResponse(event, context, responseStatus, responseData, physicalResourceId) {
  const responseBody = JSON.stringify({
    Status: responseStatus,
    Reason: `See the details in CloudWatch Log Stream: ${context.logStreamName}`,
    PhysicalResourceId: physicalResourceId,
    StackId: event.StackId,
    RequestId: event.RequestId,
    LogicalResourceId: event.LogicalResourceId,
    Data: responseData,
  });

  const parsedUrl = url.parse(event.ResponseURL);
  const options = {
    hostname: parsedUrl.hostname,
    port: 443,
    path: parsedUrl.path,
    method: "PUT",
    headers: {
      "Content-Type": "",
      "Content-Length": Buffer.byteLength(responseBody),
    },
  };

  return new Promise((resolve, reject) => {
    const request = https.request(options, response => {
      console.log(`Status code: ${response.statusCode}`);
      resolve();
    });

    request.on("error", error => {
      console.error("sendResponse Error:", error);
      reject(error);
    });

    request.write(responseBody);
    request.end();
  });
}