"use strict";

const AthenaExpress = require("athena-express"),
 aws = require("aws-sdk");

const AWS = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const athenaExpressConfig = {
    aws,
    db: "geocore_metadata",
    getStats: true
};

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});
const tableName = "tag";

const athenaExpress = new AthenaExpress(athenaExpressConfig);

var scan_results_2;
var theme;
var theme_lower;
var lang;
var keywords;
var title;
var description;
var organisation;
var id;
var coordinates;
var topicCategory;
var publication_date;
var params;
var scan_result;
var scan_results = [];
var scan_results_string;
var scan_results_1;
var theme_search;
var sqlQuery;
var results = [];


exports.handler = async(event, context, callback) => {
    

    if (event.theme === ''||event.theme === ""||typeof event.theme === 'undefined') {
        theme = undefined;
    } else {
        theme_lower = event.theme;
        theme = theme_lower.toLowerCase();
    }
    
    if (event.lang === ''||event.lang === ""||typeof event.lang === 'undefined') {
        lang = undefined;
    } else {
        lang = event.lang;
    }
    
    id = "COALESCE(features_properties_id, 'N/A') AS id";
    coordinates = "features_geometry_coordinates AS coordinates";
    topicCategory = "COALESCE(features_properties_topicCategory, 'N/A') AS topicCategory";
    publication_date = "COALESCE(features_properties_date_published_date, 'N/A') AS published";

    if (lang === "fr") {
        
        keywords = "COALESCE(features_properties_keywords_fr, 'N/A') AS keywords";
        title = "COALESCE(features_properties_title_fr, 'N/A') AS title";
        description = "COALESCE(features_properties_description_fr, 'N/A') AS description";
        organisation = "COALESCE(CAST(json_extract(json_array_get(features_properties_contact, 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
    } else {
        
        keywords = "COALESCE(features_properties_keywords_en, 'N/A') AS keywords";
        title = "COALESCE(features_properties_title_en, 'N/A') AS title";
        description = "COALESCE(features_properties_description_en, 'N/A') AS description";
        organisation = "COALESCE(CAST(json_extract(json_array_get(features_properties_contact, 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
    }

    
    var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
 
    params = {
            TableName: tableName,
            FilterExpression: "tag = :tag AND loc = :loc",
            ExpressionAttributeValues: {
                ":tag":{"S":"" + theme + ""},
                ":loc":{"S":"featured"}
        }};
        
    
   function scan() {
    
        return new Promise(resolve => {
    
        dynamodb.scan(params, function(err, data) {
        
        if (err) {
            console.log("Error", err);
        } else {
            
            scan_results = [];
            
            data.Items.forEach(function(result, index, array) {
            
                scan_result = "^" + result.uuid.S + "$|";
                scan_results.push(scan_result); 
                
            });
            
        }});
    
        resolve();
        }); 
    }
    
        
    function time() {
        return new Promise(resolve => {
        setTimeout(() => {
            //console.log(scan_results);
        resolve();
        }, 100);
    });
    } 
      
    function query() {
      
        return new Promise(async function(resolve) {  
            scan_results_string = String(scan_results);
            scan_results_1 = scan_results_string.replace(/\,/g, '');
            scan_results_2 = scan_results_1.slice(0, -1); 
    
            theme_search = "regexp_like(features_properties_id, '" + scan_results_2 + "')";
        
            sqlQuery = "SELECT " + display_fields + " FROM metadata WHERE " + theme_search + " ";
            
            results = await athenaExpress.query(sqlQuery);
            
            resolve();
        
        }); 
        
    }
  
    await scan();
    await time();
    await query();
        
    //console.log(results);
    
    callback(null, results);
    
};