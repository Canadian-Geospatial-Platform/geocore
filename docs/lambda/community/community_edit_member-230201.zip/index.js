const AWS = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});

const { 
  v4: uuidv4,
} = require('uuid');

exports.handler = async(event, context, callback) => {
    console.log(event);
    
    var key = event.key.toString();
    
    var role = event.role.toString();
    
    var params = {
        TableName: "community_roles",
            Key: {
                "key": {
                    "S": key
                }
        },
        ExpressionAttributeNames: { 
            "#R": "role"
        }, 
        ExpressionAttributeValues: { 
            ":r": { 
                S: role 
        }
        }, 
        UpdateExpression: "SET #R = :r",
        
    };
 
 dynamodb.updateItem(params, function(err, data) {
   if (err) console.log(err, err.stack); // an error occurred
   else     console.log(data);           // successful response

 });
    
    callback(null, key);
    
};