"use strict";

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */
 
const axios = require('axios');
 
const AthenaExpress = require("athena-express"),
	AWS = require("aws-sdk");

const athenaExpressConfig = {
    aws: AWS,
    db: "default",
    catalog: "dynamodb-analytics"
};

const athenaExpress = new AthenaExpress(athenaExpressConfig);

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});

exports.handler = async(event, context, callback) => {
    console.log("event is" + JSON.stringify(event));
    
    var communityId = event.communityId.toString();
    console.log(communityId);

 function one() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT * FROM community WHERE communityId = '" + communityId + "'";
            console.log(sqlQuery);

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}

await one();

        
    //console.log(results);
    
    let results = global.results;
    //console.log(global.response);
    
    callback(null, results);
};