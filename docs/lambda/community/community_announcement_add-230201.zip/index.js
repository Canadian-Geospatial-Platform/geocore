const AWS = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});

const { 
  v4: uuidv4,
} = require('uuid');

exports.handler = async(event, context, callback) => {
    console.log(event);
    
    var communityId = event.communityId.toString();
    
    var community_en = event.community_en.toString();
    
    var community_fr = event.community_fr.toString();
    
    var userId = event.userId.toString();
    
    var announcement_en = event.announcement_en.toString();
    
    var announcement_fr = event.announcement_fr.toString();
    
    var datetime = new Date(Date.now()).toLocaleString();
    
    var key = uuidv4();
    
    var params = {
        Item: {
            "key": {
                S: key
            },
            "communityId": {
                S: communityId
            },
            "community_en": {
                S: community_en
            },
            "community_fr": {
                S: community_fr
            },
            "userId": {
                S: userId
            },
            "announcement_en": {
                S: announcement_en
            },
            "announcement_fr": {
                S: announcement_fr
            },
            "datetime": {
                S: datetime
            }
    }, 
    TableName: "community_announcement"
 };
 
 dynamodb.putItem(params, function(err, data) {
   if (err) console.log(err, err.stack); // an error occurred
   else     console.log(data);           // successful response

 });
    
    callback(null, key);
    
};