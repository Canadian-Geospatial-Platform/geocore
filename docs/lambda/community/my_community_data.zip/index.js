"use strict";

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */
 
const axios = require('axios');
 
const AthenaExpress = require("athena-express"),
	AWS = require("aws-sdk");

const athenaExpressConfig = {
    aws: AWS,
    db: "default",
    catalog: "dynamodb-analytics"
};

const athenaExpress = new AthenaExpress(athenaExpressConfig);

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});

exports.handler = async(event, context, callback) => {
    console.log("event is" + JSON.stringify(event));
    
    var userId = event.userId.toString();
    var communityId;
    var communityIds = [];
    var communityIds_item = [];
    var scan_results_string;
    var scan_results_1;
    var scan_results_2;
    
    

 function one() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT communityId FROM community_roles WHERE userId = '" + userId + "'";
            console.log(sqlQuery);

            communityIds_item = await athenaExpress.query(sqlQuery);
            
            communityIds_item.Items.forEach(function(result, index, array) {
                
                communityId = " communityId = '" + result.communityId + "' OR ";
                communityIds.push(communityId);
            });
        
            resolve();
        
        });
        
}

 function two() {
      
        return new Promise(async function(resolve) {  
            console.log(communityIds);
            
            scan_results_string = String(communityIds);
            scan_results_1 = scan_results_string.replace(/\,/g, '');
            scan_results_2 = scan_results_1.slice(0, -3);
            
            let sqlQuery;
           
            sqlQuery = "SELECT * FROM community_data WHERE " + scan_results_2 + " ORDER BY datetime DESC LIMIT 10";
            console.log(sqlQuery);

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}

await one();
await two();

        
    //console.log(results);
    
    let results = global.results;
    //console.log(global.response);
    
    callback(null, results);
};