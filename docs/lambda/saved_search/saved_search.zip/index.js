const AWS = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});

const { 
  v4: uuidv4,
} = require('uuid');

exports.handler = async(event, context, callback) => {
    console.log(event);
    
    var search;
    if (event.search === ''||event.search === ""||typeof event.search === 'undefined') {
        search = "n/a";
    } else {
        search = event.search.toString();
    }
    
    var theme;
    if (event.theme === ''||event.theme === ""||typeof event.theme === 'undefined') {
        theme = "n/a";
    } else {
        theme = event.theme.toString();
    }
    
    var org;
    if (event.org === ''||event.org === ""||typeof event.org === 'undefined') {
        org = "n/a";
    } else {
        org = event.org.toString();
    }
    
    var type_filter;
    if (event.type_filter === ''||event.type_filter === ""||typeof event.type_filter === 'undefined') {
        type_filter = "n/a";
    } else {
        type_filter = event.type_filter.toString();
    }
    
    var foundational;
    if (event.foundational === ''||event.foundational === ""||typeof event.foundational === 'undefined') {
        foundational = "n/a";
    } else {
        foundational = event.foundational.toString();
    }
    
    var geo;
    if (event.geo === ''||event.geo === ""||typeof event.geo === 'undefined') {
        geo = "n/a";
    } else {
        geo = event.geo.toString();
    }
    
    var userId  = event.userId.toString();
    
    var datetime = new Date(Date.now()).toLocaleString();
    
    var lang;
    if (event.lang === ''||event.lang === ""||typeof event.lang === 'undefined') {
        lang = "n/a";
    } else {
        lang = event.lang.toString();
    }
    
    var key = uuidv4();
    
    var params = {
        Item: {
            "key": {
                S: key
            }, 
            "search": {
                S: search
            },
            "theme": {
                S: theme
            },
            "org": {
                S: org
            },
            "type_filter": {
                S: type_filter
            },
            "foundational": {
                S: foundational
            },
            "geo": {
                S: geo
            },
            "userId": {
                S: userId
            },
            "datetime": {
                S: datetime
            },
            "lang": {
                S: lang
            }
    }, 
    TableName: "saved_searches"
 };
 
 dynamodb.putItem(params, function(err, data) {
   if (err) console.log(err, err.stack); // an error occurred
   else     console.log(data);           // successful response

 });
    
    callback(null, key);
    
};