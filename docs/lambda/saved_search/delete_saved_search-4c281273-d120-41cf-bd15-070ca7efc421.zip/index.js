"use strict";

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */
 
const axios = require('axios');
 
const AthenaExpress = require("athena-express"),
	AWS = require("aws-sdk");

const athenaExpressConfig = {
    aws: AWS,
    db: "default",
    catalog: "dynamodb-analytics"
};

const athenaExpress = new AthenaExpress(athenaExpressConfig);

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});

exports.handler = async(event, context, callback) => {
    console.log("event is" + JSON.stringify(event));
    
    var searchKey = event.searchKey;
    console.log(searchKey);

 function one() {
      
        return new Promise(async function(resolve) {  
            
            var tableName = "saved_searches"
            dynamodb.deleteItem({
                "TableName": tableName, 
                "Key" :  {
                    "key": {
                        "S": searchKey
                    }
                }
            }, function (err, data) {
                if (err) {
                    context.fail('FAIL:  Error deleting item from dynamodb - ' + err);
                }
                else {
                    console.log("DEBUG:  deleteItem worked. ");
                    context.succeed(data);
                }
            });

            resolve();
        
        });
        
}

await one();

        
    //console.log(results);
    
    let results = global.results;
    //console.log(global.response);
    
    callback(null, results);
};