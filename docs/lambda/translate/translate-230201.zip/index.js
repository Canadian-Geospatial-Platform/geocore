const { TranslateClient, TranslateTextCommand } = require("@aws-sdk/client-translate");

exports.handler = async (event, context, callback) => {
    
    var text = event.text;
    var from_lang = event.from_lang;
    var to_lang = event.to_lang;
    
    const client = new TranslateClient({ region: "us-east-1" });

    const text_to_translate = {
      SourceLanguageCode: from_lang,
      TargetLanguageCode: to_lang,
      Text: text
    };
      
    const translate_command = new TranslateTextCommand(text_to_translate);  
    let translation;
    
    try {
      const translate = await client.send(translate_command);
        translation = translate.TranslatedText;
    } catch (error) {
      console.log(error);
    } 
    
    const response = {
        statusCode: 200,
        body: translation
    }; 
    return response;
    };