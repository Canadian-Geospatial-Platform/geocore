const AWS = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});

const { 
  v4: uuidv4,
} = require('uuid');

exports.handler = async(event, context, callback) => {
    console.log(event);
    
    var search;
    if (event.search === ''||event.search === ""||typeof event.search === 'undefined') {
        search = '';
    } else {
        search = event.search;
    }
    
    var theme;
    if (event.theme === ''||event.theme === ""||typeof event.theme === 'undefined') {
        theme = '';
    } else {
        theme = event.theme;
    }
    
    var org;
    if (event.org === ''||event.org === ""||typeof event.org === 'undefined') {
        org = '';
    } else {
        org = event.org;
    }
    
    var type_filter;
    if (event.type_filter === ''||event.type_filter === ""||typeof event.type_filter === 'undefined') {
        type_filter = '';
    } else {
        type_filter = event.type_filter;
    }
    
    var foundational;
    if (event.foundational === ''||event.foundational === ""||typeof event.foundational === 'undefined') {
        foundational = '';
    } else {
        foundational = event.foundational;
    }
    
    var geo;
    if (event.geo === ''||event.geo === ""||typeof event.geo === 'undefined') {
        geo = '';
    } else {
        geo = event.geo;
    }
    
    var uuid;
    if (event.uuid === ''||event.uuid === ""||typeof event.uuid === 'undefined') {
        uuid = '';
    } else {
        uuid = event.uuid;
    }   
    
    var resource;
    if (event.resource === ''||event.resource === ""||typeof event.resource === 'undefined') {
        resource = '';
    } else {
        resource = event.resource;
    }  
    
    var resource_type;
    if (event.resource_type === ''||event.resource_type === ""||typeof event.resource_type === 'undefined') {
        resource_type = '';
    } else {
        resource_type = event.resource_type;
    }
    
    var datetime = new Date(Date.now()).toLocaleString();
    
    var loc;
    if (event.loc === ''||event.loc === ""||typeof event.loc === 'undefined') {
        loc = '';
    } else {
        loc = event.loc;
    }
    
    var lang;
    if (event.lang === ''||event.lang === ""||typeof event.lang === 'undefined') {
        lang = '';
    } else {
        lang = event.lang;
    }
    
    var type;
    if (event.type === ''||event.type === ""||typeof event.type === 'undefined') {
        type = '';
    } else {
        type = event.type;
    }
    
    var key = uuidv4();
    
    var params = {
        Item: {
            "key": {
                S: key
            }, 
            "search": {
                S: search
            },
            "theme": {
                S: theme
            },
            "org": {
                S: org
            },
            "type_filter": {
                S: type_filter
            },
            "foundational": {
                S: foundational
            },
            "geo": {
                S: geo
            },
            "uuid": {
                S: uuid
            },
            "resource": {
                S: resource
            },
            "resource_type": {
                S: resource_type
            },
            "datetime": {
                S: datetime
            },
            "loc": {
                S: loc
            },
            "lang": {
                S: lang
            },
            "type": {
                S: type
            }
    }, 
    TableName: "analytics"
 };
 
 dynamodb.putItem(params, function(err, data) {
   if (err) console.log(err, err.stack); // an error occurred
   else     console.log(data);           // successful response

 });
    
    callback(null, key);
    
};