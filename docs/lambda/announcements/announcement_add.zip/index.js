const AWS = require("aws-sdk");

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});

const { 
  v4: uuidv4,
} = require('uuid');

exports.handler = async(event, context, callback) => {
    console.log(event);
    
    var announcement_en = event.announcement_en.toString();
    
    var announcement_fr = event.announcement_fr.toString();
    
    var datetime = new Date(Date.now()).toLocaleString();
    
    var key = uuidv4();
    
    var params = {
        Item: {
            "key": {
                S: key
            },
            "announcement_en": {
                S: announcement_en
            },
            "announcement_fr": {
                S: announcement_fr
            },
            "datetime": {
                S: datetime
            }
    }, 
    TableName: "announcements"
 };
 
 dynamodb.putItem(params, function(err, data) {
   if (err) console.log(err, err.stack); // an error occurred
   else     console.log(data);           // successful response

 });
    
    callback(null, key);
    
};