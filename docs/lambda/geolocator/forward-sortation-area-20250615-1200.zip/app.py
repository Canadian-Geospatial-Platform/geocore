import os
import re
import json
import boto3
import requests
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

def parse_query(q):
    q = q.strip()
    if "," in q:
        try:
            lon, lat = map(float, q.split(","))
            return {"type": "Point", "coordinates": [lon, lat]}
        except ValueError:
            pass  # Fall through to treat as CFSAUID
    return q.upper()

def lambda_handler(event, context):
    """
    Lambda function handler to process logs from a CloudWatch log group and index them into OpenSearch.
    """
    # Environment variable configuration
    region         = os.environ['MY_AWS_REGION']
    aos_host       = os.environ['OS_ENDPOINT']
    os_secret_id   = os.environ['OS_SECRET_ID']
    fsa_index_name = os.environ['INDEX_NAME']

    # Get event variables
    q = event.get("q")

    # Use IAM credentials instead
    credentials = boto3.Session().get_credentials()
    aws_auth = AWS4Auth(credentials.access_key, credentials.secret_key, region, 'es', session_token=credentials.token)

    # Initialize OpenSearch client
    os_client = OpenSearch(
        hosts=[{'host': aos_host, 'port': 443}],
        http_auth=aws_auth,
        use_ssl=True,
        verify_certs=True,
        ssl_assert_hostname = False,
        ssl_show_warn = False,
        connection_class=RequestsHttpConnection
    )

    try:
        response = os_client.info()
        print("OpenSearch Connected:", response)
    except Exception as e:
        print("OpenSearch Connection Failed:", e)

    parsed = parse_query(q)
    
    should_clauses = []

    # Case 1: It parsed as a geo_point
    if isinstance(parsed, dict) and "type" in parsed:
        should_clauses.append({
            "geo_shape": {
                "location": {
                    "shape": parsed,
                    "relation": "intersects"
                }
            }
        })

    # Case 2: It’s a CFSAUID
    else:
        should_clauses.append({
            "term": {
                "attributes.CFSAUID.keyword": parsed
            }
        })

    query = {
        "query": {
            "bool": {
                "should": should_clauses,
                "minimum_should_match": 1
            }
        }
    }

    url = f"https://{aos_host}/{fsa_index_name}/_search"
    print(url)
    headers = {"Content-Type": "application/json"}

    try:
        response = requests.post(
            url,
            auth=aws_auth,
            headers=headers,
            data=json.dumps(query)
        )

        json_object = json.loads(response.text)

        name = json_object['hits']['hits'][0]['_source']['name']
        long = json_object['hits']['hits'][0]['_source']['attributes']['LONG']
        lat = json_object['hits']['hits'][0]['_source']['attributes']['LAT']
        area = json_object['hits']['hits'][0]['_source']['attributes']['LANDAREA']
        pt = json_object['hits']['hits'][0]['_source']['attributes']['PRNAME']

        bbox_array = [
            json_object['hits']['hits'][0]['_source']['bbox']['coordinates'][0][0],  # minX (top-left X)
            json_object['hits']['hits'][0]['_source']['bbox']['coordinates'][1][1],  # minY (bottom-right Y)
            json_object['hits']['hits'][0]['_source']['bbox']['coordinates'][1][0],  # maxX (bottom-right X)
            json_object['hits']['hits'][0]['_source']['bbox']['coordinates'][0][1],  # maxY (top-left Y)
        ]

        response_json = {
            "key": "forward-sortation-area",
            "name": name,
            "province": pt,
            "category": "Postal Code",
            "long": long,
            "lat": lat,
            "bbox": bbox_array,
            "tag": str(area) + " km^3"
        }

        return [ 
            response_json
            ]
    
    except requests.RequestException as e:
        return {
            "statusCode": 500,
            "body": json.dumps(f"Request error: {str(e)}")
        }
    

