class MissingParameterException(Exception):
    pass

class InvalidParameterException(Exception):
    pass
