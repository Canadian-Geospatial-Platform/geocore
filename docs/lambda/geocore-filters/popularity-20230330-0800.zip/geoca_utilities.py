import os
import boto3

from botocore.exceptions import ClientError

region = os.environ['REGION_NAME']

def geoca_analytics_helper(uuid, dynamodb=None):
    
    types = ['use', 'access']

    count = 0
    for type in types:
        uuid = uuid.replace('.geojson', '')
        dynamodb_client = boto3.client('dynamodb', region_name=region)
        response = dynamodb_client.query(
            TableName='analytics',
            IndexName='uuid-type-index',
            KeyConditionExpression='#uuid = :uuid AND #type = :type',
            ExpressionAttributeNames={
              '#uuid': 'uuid',
              '#type': 'type'
            },
            ExpressionAttributeValues={
              ':uuid': {'S':uuid},
              ':type': {'S':type}
            }
        )
        count += response['Count']
    
    #debug
    #if count > 0:
    #    print("UUID", uuid, " TYPE ", type, " COUNT ", count, "\n")
    
    return uuid, count
