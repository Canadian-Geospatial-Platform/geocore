import os
import boto3
import datetime
from botocore.exceptions import ClientError

region = os.environ['REGION_NAME']

def create_uuid_popularity_table(popularity_table, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', region_name=region)

    table = dynamodb.create_table(
        TableName=popularity_table,
        KeySchema=[
            {
                'AttributeName': 'uuid',
                'KeyType': 'HASH'  # Partition key
            },
            {
                'AttributeName': 'popularity',
                'KeyType': 'RANGE'  # Sort key
            }
        ],
        AttributeDefinitions=[
            {
                'AttributeName': 'uuid',
                'AttributeType': 'S'
            },
            {
                'AttributeName': 'popularity',
                'AttributeType': 'N'
            }
        ],
        BillingMode='PAY_PER_REQUEST',
    )
    print(popularity_table, " table created.")
    return table
    
def create_uuid_popularity(uuid, popularity, popularity_table, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', region_name=region)
        
    dateTime = datetime.datetime.utcnow().now()
    dateTime = dateTime.isoformat()[:-7] + 'Z'
    
    table = dynamodb.Table(popularity_table)
    
    try:
        response = table.put_item(
           Item={
                'uuid': uuid,
                'popularity': popularity,
                'dt': dateTime
            }
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        return response

def read_uuid_popularity(uuid, popularity_table, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', region_name=region)

    table = dynamodb.Table(popularity_table)
    try:
        response = table.query(
            KeyConditionExpression=Key('uuid').eq(uuid)
        )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        return response['Items']

def update_uuid_popularity_changeDate(uuid, popularity, changeDate, popularity_table, dynamodb=None):
    
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', region_name=region)
        
    dateTime = datetime.datetime.utcnow().now()
    dateTime = dateTime.isoformat()[:-7] + 'Z'

    table = dynamodb.Table(popularity_table)
    try:
        response = table.update_item(
            Key={
                'uuid': uuid,
                'popularity': popularity
            },
            UpdateExpression="set changeDate=:changeDate",
            ExpressionAttributeValues={
                ':changeDate': changeDate
            },
            ReturnValues="UPDATED_NEW"
        )
    except ClientError as e:
        print(e)
    else:
        return response

def delete_uuid_popularity(uuid, popularity, popularity_table, dynamodb=None):
    
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', region_name=region)
        
    table = dynamodb.Table(popularity_table)
    try:
        response = table.delete_item(Key={'uuid': uuid, 'popularity': popularity })
    except ClientError as e:
        print(e)
        raise
    else:
        return response
        
def query_uuid(uuid, popularity_table, dynamodb=None):
    
    dynamodb_client = boto3.client('dynamodb', region_name=region)
    
    try:
        response = dynamodb_client.query(
            TableName=popularity_table,
            KeyConditionExpression='#uuid = :uuid',
            ExpressionAttributeNames={
              '#uuid': 'uuid'
            },
            ExpressionAttributeValues={
              ':uuid': {'S':uuid}
            }
        )
    except ClientError as e:
        print(e)
    else:
        return response

def delete_uuid_popularity_table(popularity_table, dynamodb=None):
    if not dynamodb:
        dynamodb = boto3.resource('dynamodb', region_name=region)

    table = dynamodb.Table(popularity_table)
    
    try:
        table.delete()
    except ClientError as e:
        print(popularity_table, "table could NOT be deleted.")
    else:
        print(popularity_table, " table deleted.")

"""
    class Dynamodb:
        def __init__(self, region):
            #assuming aws secrets are know since we are running in lambda
            self._region = region
            self._dynamodb = boto3.resource('dynamodb', region_name=_region)
             0
    def create_table (self, table_name, schema, attributes, throughput, gsi=None): 
        #Create a table and wait for completion
        
        try:
            if(len(global_secondary_indexes)>0):
                table = self._dynamodb.create_table(
                    TableName=table_name,
                    KeySchema=schema,
                    AttributeDefinitions=attributes,
                    GlobalSecondaryIndexes=gsi,
                    ProvisionedThroughput=throughput
                )
            else:
                table = self._dynamodb.create_table(
                    TableName=table_name,
                    KeySchema=schema,
                    AttributeDefinitions=attributes,
                    ProvisionedThroughput=throughput
                )
            #wait for table completion
            table.meta.client.get_waiter('table_exists').wait(TableName=table)
        except ClientError as e:
            print(table, "table could NOT be created.")
            return False
        else:
            return True

        
    def create_item(self, table_name, item):
        #Create an item (dict) in table_name
        
        try:
            table = self._dynamodb.Table(table_name)
            response = table.put_item(Item=item)
        except ClientError as e:
            print(e.response['Error']['Message'])
        else:
            return True
    
    def read_item(self, table_name, key):
        #Read an item by key
        
        try:
            table = self._dynamodb.Table(table_name)
            response = table.get_item(Key=key)
            item = response.get('Item')
            if item is not None:
                return item
            else:
                return ItemNotFound(table_name, key)
        except ClientError as e:
            print(e.response['Error']['Message'])
            return False
        else:
            return True
            
    def query_item(self, table_name, expression, gsi=None):
        #Query for item by expression and gsi
        
        try:
            table = self._dynamodb.Table(table_name)
            if gsi != None:
                response = table.query(
                    IndexName=gsi,
                    KeyConditionExpression=expression
                )
            else:
                response = table.query(
                    KeyConditionExpression=expression
                )
            return response.get('Items')
        except ClientError as e:
            print(e.response['Error']['Message'])
            return False
        else:
            return True
            
    def update_item(self, table_name, key,
                    attributes_to_update, operation="UPDATE_EXISTING_ATTRIBUTE_OR_ADD_NEW_ATTRIBUTE"):
        pass
    
    def delete_table (self, table_name):
        #Delete a table and wait for completion
        
        try:
            table = self._dynamodb.Table(table_name)
            table.delete()
            #wait for table delete completion
            table.meta.client.get_waiter('table_not_exists').wait(TableName=table_name)
        except ClientError as e:
            print(table, "table could NOT be deleted:", e.response['Error']['Message'])
            return False
        else:
            return True
"""