import boto3
import base64
import requests
from PIL import Image
from io import BytesIO

def lambda_handler(event, context):
    # Get the image URL from the query parameters
    image_url = event['queryStringParameters']['url']
    try:
        image_looking_side = event['queryStringParameters']['side'].lower()
    except:
        image_looking_side = ''
    
    # Fetch the image
    response = requests.get(image_url)
    if response.status_code != 200:
        return {
            'statusCode': 400,
            'body': 'Error fetching the image'
        }
    
    # Open the image
    img = Image.open(BytesIO(response.content))
    
    if image_looking_side == 'descending':
        # Ascending  - flip the image left right
        flipped_img = img.transpose(Image.FLIP_LEFT_RIGHT)
    elif image_looking_side == 'ascending':
        # Descending - flip the image top bottom
        flipped_img = img.transpose(Image.FLIP_TOP_BOTTOM)
    else:
        # Do nothing to the image
        flipped_img = img
    
    # Save the flipped image to a BytesIO object
    buffer = BytesIO()
    flipped_img.save(buffer, format="PNG")
    buffer.seek(0)
    
    # Encode the image to base64
    img_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    
    # Debug - Upload the image to S3
    #s3 = boto3.client('s3')
    #bucket_name = 'interpolation-tiff-files'  # Replace with your S3 bucket name
    #object_key = 'flipped_image.png'
    #s3.upload_fileobj(buffer, bucket_name, object_key, ExtraArgs={'ContentType': 'image/png'})
    
    # Return the image as body in base64 string
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Content-Type': 'image/png',
            'Access-Control-Allow-Methods': 'GET, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, X-Amz-Date, Authorization, X-Api-Key, X-Amz-Security-Token'
        },
        'body': img_base64,
        'isBase64Encoded': True
    }