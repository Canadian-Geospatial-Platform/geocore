"use strict";

/* 
 * AWS Credentials are not required here
 * because the IAM Role assumed by this Lambda
 * has the necessary permission to execute Athena queries
 * and store the result in Amazon S3 bucket
 */
 
const axios = require('axios');
 
const AthenaExpress = require("athena-express"),
	AWS = require("aws-sdk");

const athenaExpressConfig = {
    aws: AWS,
    db: "default",
    catalog: "dynamodb-analytics"
};

const athenaExpressConfig1 = {
    aws: AWS,
    db: "geocore_metadata"
};

const athenaExpress = new AthenaExpress(athenaExpressConfig);
const athenaExpress1 = new AthenaExpress(athenaExpressConfig1);

const dynamodb = new AWS.DynamoDB({apiVersion: "2012-08-10"});
const tableName = "tag";
const theme_tableName = "theme";

const docClient = new AWS.DynamoDB.DocumentClient();


global.results;
global.pre_results;
global.pre_results_1;
global.lang;
global.theme;
global.min;
global.max;
global.keyword_only;
global.results_Array_sorted = [];

global.org;
global.uuid;
global.results_preArray;
global.results_Array = [];
global.keyword_uuid;
global.results_Array_results_string;

global.response;
global.response_final;
global.response_data = [];
global.response_data_1;
global.response_data_result;
global.response_data_final = [];
global.response_data_final_1;
global.response_data_final_result;
global.response_data_final_results_string;
global.response_Array_1;
global.response_data_results_string;

global.responseA_data_result;
global.responseA_data = [];
global.responseA_data_results_string;
global.responseA_data_1;
global.responseA;

global.responseB_data_result;
global.responseB_data = [];
global.responseB_data_results_string;
global.responseB_data_1;
global.responseB;

global.response_82;

global.theme_search = '';
global.pre_theme_string;

global.legal_scan_results = [];
global.legal_scan_result;
global.legal_scan_results_string;
global.legal_1;

global.emergency_scan_results = [];
global.emergency_scan_result;
global.emergency_scan_results_string;
global.emergency_1;

global.foundational_scan_results = [];
global.foundational_scan_result;
global.foundational_scan_results_string;
global.foundational_1;

global.admin;
global.economy;
global.environment;
global.imagery;
global.infrastructure;
global.science;
global.society;
global.legal;
global.emergency;
global.foundational;


var keywords;
var title;
var description;
var organisation;
var id;
var coordinates;
var topicCategory;
var publication_date;


const uuids = [];

exports.handler = async(event, context, callback) => {
    console.log(event);
    
    var type;
    if (event.type === ''||event.type === ""||typeof event.type === 'undefined') {
        type = undefined;
    } else {
        type = event.type;
    }
    
    var theme_lower;
    if (event.theme === ''||event.theme === ""||typeof event.theme === 'undefined') {
        global.theme = undefined;
    } else {
        theme_lower = event.theme;
        global.theme = theme_lower.toLowerCase();
    }
    
    var org;
    var org_lower;
    if (event.org === ''||event.org === ""||typeof event.org === 'undefined') {
        org = undefined;
    } else {
        org_lower = event.org;
        org = org_lower.toLowerCase();
    }
    
    var query_id = event.id;
    
    if (event.lang === ''||event.lang === ""||typeof event.lang === 'undefined') {
        global.lang = undefined;
    } else {
        global.lang = event.lang;
    }
    
    global.min = '1';
    global.max = '10';
    global.keyword_only = 'true';
    
    if (event.uuid === ''||event.uuid === ""||typeof event.uuid === 'undefined') {
        global.uuid = undefined;
    } else {
        global.uuid = event.uuid;
    }


 function one() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT search, COUNT(*) AS count FROM analytics WHERE date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p') >= current_date - interval '30' day AND type = 'search' AND search != '' GROUP BY search ORDER BY count DESC LIMIT 10";

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}

 function two() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS searches FROM analytics WHERE date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p') >= current_date - interval '30' day AND type = 'search'";

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}

 function three() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses FROM analytics WHERE date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p') >= current_date - interval '30' day AND (type = 'access' OR type = 'use')";

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}
    
 function four_one() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses, uuid FROM analytics WHERE date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p') >= current_date - interval '30' day AND (type = 'access' OR type = 'use') GROUP BY uuid ORDER BY accesses DESC LIMIT 10";

            global.pre_results = await athenaExpress.query(sqlQuery);
            
            console.log(global.pre_results);
            
            resolve();
        
        });
        
}

 function four_two() {
      
        return new Promise(async function(resolve) {
            
            global.pre_results.Items.forEach(async function(result, index, array) {
                        
                global.responseB_data_result = result.uuid + "|";
                global.responseB_data.push(global.responseB_data_result); 
                            
            });
            
            global.responseB_data_results_string = String(global.responseB_data);
            global.responseB_data_1 = global.responseB_data_results_string.replace(/\,/g, '');
            global.responseB = global.responseB_data_1.slice(0, -1);
                        
            id = "COALESCE(features_properties_id, 'N/A') AS id";
            coordinates = "features_geometry_coordinates AS coordinates";
            topicCategory = "COALESCE(features_properties_topicCategory, 'N/A') AS topicCategory";
            publication_date = "COALESCE(features_properties_date_published_date, 'N/A') AS published";

            if (global.lang === "fr") {
        
                keywords = "COALESCE(features_properties_keywords_fr, 'N/A') AS keywords";
                title = "COALESCE(features_properties_title_fr, 'N/A') AS title";
                description = "COALESCE(features_properties_description_fr, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
            } else {
        
                keywords = "COALESCE(features_properties_keywords_en, 'N/A') AS keywords";
                title = "COALESCE(features_properties_title_en, 'N/A') AS title";
                description = "COALESCE(features_properties_description_en, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
            }

            var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
                        
            let sqlQuery2;
            
            sqlQuery2 = "SELECT " + display_fields + " FROM metadata WHERE regexp_like(features_properties_id, '" + global.responseB + "')";
                       
            await athenaExpress1.query(sqlQuery2)
            .then(function (response){
                
                response.Items.forEach(async function(result, index, array) {
                    
                    var item = response.Items[index];
                    var id = "" + item.id + "";
                    var title = "" + item.title + "";
                    var coordinates = "" + item.coordinates + "";
                    var description = "" + item.description + "";
                    var publication_date = "" + item.publication_date + "";
                    var keywords = "" + item.keywords + "";
                    var topicCategory = "" + item.topicCategory + "";
                    var organisation = "" + item.organisation + "";
                    
                    var access_number;
                    
                    global.pre_results.Items.forEach(async function(result, index, array) {
                        
                        var access_uuid = global.pre_results.Items[index].uuid;
                                            
                        if (access_uuid === id) {
                        
                            access_number = global.pre_results.Items[index].accesses;
                        
                        }
                        
                           
                    });

                            
                            
                    global.results_preArray = {
                        "accesses": access_number,
                        "id": id,
                        "title": title,
                        "coordinates": coordinates,
                        "description": description,
                        "publication_date": publication_date,
                        "keywords": keywords,
                        "topicCategory": topicCategory,
                        "organisation": organisation
                    },
                    global.results_Array.push(global.results_preArray);

                    });
            });
            
            global.results_Array_sorted = global.results_Array.sort((a, b) => parseFloat(b.accesses) - parseFloat(a.accesses));
            global.results = global.results_Array_sorted;
            
            resolve();
            
      });

}

 function five_one() {
      
        return new Promise(async function(resolve) {
            
            global.pre_results = [];
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses, uuid FROM analytics WHERE (type = 'access' OR type = 'use') GROUP BY uuid ORDER BY accesses DESC LIMIT 10";

            global.pre_results = await athenaExpress.query(sqlQuery);
            
            resolve();
        
        });
        
}

 function five_two() {
      
        return new Promise(async function(resolve) {
            
            global.pre_results.Items.forEach(async function(result, index, array) {
                        
                global.responseB_data_result = result.uuid + "|";
                global.responseB_data.push(global.responseB_data_result); 
                            
            });
            
            global.responseB_data_results_string = String(global.responseB_data);
            global.responseB_data_1 = global.responseB_data_results_string.replace(/\,/g, '');
            global.responseB = global.responseB_data_1.slice(0, -1);
                        
            id = "COALESCE(features_properties_id, 'N/A') AS id";
            coordinates = "features_geometry_coordinates AS coordinates";
            topicCategory = "COALESCE(features_properties_topicCategory, 'N/A') AS topicCategory";
            publication_date = "COALESCE(features_properties_date_published_date, 'N/A') AS published";

            if (global.lang === "fr") {
        
                keywords = "COALESCE(features_properties_keywords_fr, 'N/A') AS keywords";
                title = "COALESCE(features_properties_title_fr, 'N/A') AS title";
                description = "COALESCE(features_properties_description_fr, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
            } else {
        
                keywords = "COALESCE(features_properties_keywords_en, 'N/A') AS keywords";
                title = "COALESCE(features_properties_title_en, 'N/A') AS title";
                description = "COALESCE(features_properties_description_en, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
            }
            
            var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
                        
            let sqlQuery2;
            
            sqlQuery2 = "SELECT " + display_fields + " FROM metadata WHERE regexp_like(features_properties_id, '" + global.responseB + "')";
                       
            await athenaExpress1.query(sqlQuery2)
            .then(function (response){
                            
                response.Items.forEach(async function(result, index, array) {
                            
                    var access_number = global.pre_results.Items[index].accesses;
                            
                    var item = response.Items[index];
                    var id = "" + item.id + "";
                    var title = "" + item.title + "";
                    var coordinates = "" + item.coordinates + "";
                    var description = "" + item.description + "";
                    var publication_date = "" + item.publication_date + "";
                    var keywords = "" + item.keywords + "";
                    var topicCategory = "" + item.topicCategory + "";
                    var organisation = "" + item.organisation + "";
                            
                            
                    global.results_preArray = {
                        "acceses": access_number,
                        "id": id,
                        "title": title,
                        "coordinates": coordinates,
                        "description": description,
                        "publication_date": publication_date,
                        "keywords": keywords,
                        "topicCategory": topicCategory,
                        "organisation": organisation
                    },
                    global.results_Array.push(global.results_preArray);
                            
                    });
            });
            
            global.results_Array_sorted = global.results_Array.sort((a, b) => parseFloat(b.accesses) - parseFloat(a.accesses));
            global.results = global.results_Array_sorted;
            
            resolve();
            
      });

}

function six() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS searches FROM analytics WHERE date_trunc('month', date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p')) = date_trunc('month', (date_add('month', -1, current_date))) AND type = 'search'";

            global.results = await athenaExpress.query(sqlQuery);

            resolve();
        
        });
        
}

 function seven() {
      
        return new Promise(async function(resolve) {  
            
            let sqlQuery;
           
            sqlQuery = "SELECT COUNT(*) AS accesses FROM analytics WHERE date_trunc('month', date_parse(datetime, '%m/%d/%Y, %h:%i:%S %p')) = date_trunc('month', (date_add('month', -1, current_date))) AND (type = 'access' OR type = 'use')";

            global.pre_results = await athenaExpress.query(sqlQuery);
            
            global.results = global.pre_results;

            resolve();
        
        });
        
}

 function eight_one() {
      
        return new Promise(async function(resolve) {
            
            id = "COALESCE(features_properties_id, 'N/A') AS id";
            
            let sqlQuery1;
            
            sqlQuery1 = "SELECT " + id + " FROM metadata WHERE " + global.theme_search + "";
            
            await athenaExpress1.query(sqlQuery1)
            .then(function (response){
                global.responseA_data = [];
                
                response.Items.forEach(function(result, index, array) {
                
                    global.responseA_data_result = result.id + "|";
                    global.responseA_data.push(global.responseA_data_result); 
                
                });
                
                global.responseA_data_results_string = String(global.responseA_data);
                global.responseA_data_1 = global.responseA_data_results_string.replace(/\,/g, '');
                global.responseA = global.responseA_data_1.slice(0, -1);
                //console.log(global.responseA);
            });
                    
        resolve();

        });

}

 function eight_two() {
      
        return new Promise(async function(resolve) { 
            
            let sqlQuery;
            
            sqlQuery = "SELECT COUNT(*) AS accesses, uuid FROM analytics WHERE regexp_like(uuid, '" + global.responseA + "') AND (type = 'access' OR type = 'use') GROUP BY uuid ORDER BY accesses DESC LIMIT 10";
            
            await athenaExpress.query(sqlQuery)
            .then(function (response){

                global.response_82 = response;
                
            });
            
            resolve();
            
      });

}

 function eight_three() {
      
        return new Promise(async function(resolve) {
            
            global.responseB_data = [];
            
            global.response_82.Items.forEach(async function(result, index, array) {
                        
                global.responseB_data_result = result.uuid + "|";
                global.responseB_data.push(global.responseB_data_result); 
                            
            });
                
            global.responseB_data_results_string = String(global.responseB_data);
            global.responseB_data_1 = global.responseB_data_results_string.replace(/\,/g, '');
            global.responseB = global.responseB_data_1.slice(0, -1);
                        
            id = "COALESCE(features_properties_id, 'N/A') AS id";
            coordinates = "features_geometry_coordinates AS coordinates";
            topicCategory = "COALESCE(features_properties_topicCategory, 'N/A') AS topicCategory";
            publication_date = "COALESCE(features_properties_date_published_date, 'N/A') AS published";

            if (global.lang === "fr") {
        
                keywords = "COALESCE(features_properties_keywords_fr, 'N/A') AS keywords";
                title = "COALESCE(features_properties_title_fr, 'N/A') AS title";
                description = "COALESCE(features_properties_description_fr, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
            } else {
        
                keywords = "COALESCE(features_properties_keywords_en, 'N/A') AS keywords";
                title = "COALESCE(features_properties_title_en, 'N/A') AS title";
                description = "COALESCE(features_properties_description_en, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
            }

            var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
                        
            let sqlQuery2;
            
            sqlQuery2 = "SELECT " + display_fields + " FROM metadata WHERE regexp_like(features_properties_id, '" + global.responseB + "')";
                       
            await athenaExpress1.query(sqlQuery2)
            .then(function (response){
                global.results_Array = [];
                            
                response.Items.forEach(async function(result, index, array) {
                            
                    var access_number = global.response_82.Items[index].accesses;
                            
                    var item = response.Items[index];
                    var accesses = '"acceses": "' + access_number + '"';
                    var id = "" + item.id + "";
                    var title = "" + item.title + "";
                    var coordinates = "" + item.coordinates + "";
                    var description = "" + item.description + "";
                    var publication_date = "" + item.publication_date + "";
                    var keywords = "" + item.keywords + "";
                    var topicCategory = "" + item.topicCategory + "";
                    var organisation = "" + item.organisation + "";
                            
                            
                    global.results_preArray = {
                        "acceses": access_number,
                        "id": id,
                        "title": title,
                        "coordinates": coordinates,
                        "description": description,
                        "publication_date": publication_date,
                        "keywords": keywords,
                        "topicCategory": topicCategory,
                        "organisation": organisation
                    },
                    global.results_Array.push(global.results_preArray);
                    global.results = global.results_Array;
                            
                    });
            });

            
            resolve();
            
      });

}

 function nine_one() {
      
        return new Promise(async function(resolve) {
            
            id = "COALESCE(features_properties_id, 'N/A') AS id";
            var organisation_filter = "regexp_like(COALESCE(CAST(json_extract(json_array_get(LOWER(features_properties_contact), 0), '$.organisation.en') AS VARCHAR), 'N/A'), '" + org + "')";
            
            let sqlQuery1;
            
            sqlQuery1 = "SELECT " + id + " FROM metadata WHERE " + organisation_filter + "";
            
            await athenaExpress1.query(sqlQuery1)
            .then(function (response){
                global.responseA_data = [];
                
                response.Items.forEach(function(result, index, array) {
                
                    global.responseA_data_result = result.id + "|";
                    global.responseA_data.push(global.responseA_data_result); 
                
                });
                
                global.responseA_data_results_string = String(global.responseA_data);
                global.responseA_data_1 = global.responseA_data_results_string.replace(/\,/g, '');
                global.responseA = global.responseA_data_1.slice(0, -1);
                //console.log(global.responseA);
            });
                    
        resolve();

        });

}

 function nine_two() {
      
        return new Promise(async function(resolve) { 
            
            let sqlQuery;
            
            sqlQuery = "SELECT COUNT(*) AS accesses, uuid FROM analytics WHERE regexp_like(uuid, '" + global.responseA + "') AND (type = 'access' OR type = 'use') GROUP BY uuid ORDER BY accesses DESC LIMIT 10";
            
            await athenaExpress.query(sqlQuery)
            .then(function (response){

                global.response_82 = response;
                console.log(global.response_82);
                
            });
            
            resolve();
            
      });

}

 function nine_three() {
      
        return new Promise(async function(resolve) {
            
            global.responseB_data = [];
            
            global.response_82.Items.forEach(async function(result, index, array) {
                        
                global.responseB_data_result = result.uuid + "|";
                global.responseB_data.push(global.responseB_data_result); 
                            
            });
                
            global.responseB_data_results_string = String(global.responseB_data);
            global.responseB_data_1 = global.responseB_data_results_string.replace(/\,/g, '');
            global.responseB = global.responseB_data_1.slice(0, -1);
                        
            id = "COALESCE(features_properties_id, 'N/A') AS id";
            coordinates = "features_geometry_coordinates AS coordinates";
            topicCategory = "COALESCE(features_properties_topicCategory, 'N/A') AS topicCategory";
            publication_date = "COALESCE(features_properties_date_published_date, 'N/A') AS published";

            if (global.lang === "fr") {
        
                keywords = "COALESCE(features_properties_keywords_fr, 'N/A') AS keywords";
                title = "COALESCE(features_properties_title_fr, 'N/A') AS title";
                description = "COALESCE(features_properties_description_fr, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.fr') AS VARCHAR), 'N/A') AS organisation";
        
            } else {
        
                keywords = "COALESCE(features_properties_keywords_en, 'N/A') AS keywords";
                title = "COALESCE(features_properties_title_en, 'N/A') AS title";
                description = "COALESCE(features_properties_description_en, 'N/A') AS description";
                organisation = "COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.en') AS VARCHAR), 'N/A') AS organisation";
        
            }

            var display_fields = "" + id + ", " + coordinates + ", " + title + ", " + description + ", " + publication_date + ", " + keywords + ", " + topicCategory + ", " + organisation + "";
                        
            let sqlQuery2;
            
            sqlQuery2 = "SELECT " + display_fields + " FROM metadata WHERE regexp_like(features_properties_id, '" + global.responseB + "')";
                       
            await athenaExpress1.query(sqlQuery2)
            .then(function (response){
                global.results_Array = [];
                            
                response.Items.forEach(async function(result, index, array) {
                            
                    var access_number = global.response_82.Items[index].accesses;
                            
                    var item = response.Items[index];
                    var accesses = '"acceses": "' + access_number + '"';
                    var id = "" + item.id + "";
                    var title = "" + item.title + "";
                    var coordinates = "" + item.coordinates + "";
                    var description = "" + item.description + "";
                    var publication_date = "" + item.publication_date + "";
                    var keywords = "" + item.keywords + "";
                    var topicCategory = "" + item.topicCategory + "";
                    var organisation = "" + item.organisation + "";
                            
                            
                    global.results_preArray = {
                        "acceses": access_number,
                        "id": id,
                        "title": title,
                        "coordinates": coordinates,
                        "description": description,
                        "publication_date": publication_date,
                        "keywords": keywords,
                        "topicCategory": topicCategory,
                        "organisation": organisation
                    },
                    global.results_Array.push(global.results_preArray);
                    global.results = global.results_Array;
                            
                    });
            });

            
            resolve();
            
      });

}

function ten() {
     return new Promise(async function(resolve) { 

            let d = new Date();
            let thirty_days_ago = d.setDate(d.getDate() - 30);
            var thirty_days_ago_datetime = new Date(thirty_days_ago)
            let thirty_days_ago_datetime_locale = (thirty_days_ago_datetime.getMonth() + 1) + "/" + thirty_days_ago_datetime.getDate() + "/" + thirty_days_ago_datetime.getFullYear();
        
            console.log(thirty_days_ago_datetime_locale)
            console.log(global.uuid)
            
            const all_time_use = {
              TableName : 'analytics_dev',
              IndexName: 'uuid-type-index',
              KeyConditionExpression: '#uuid = :uuid AND #type = :type',
              ExpressionAttributeNames: { 
                '#uuid': 'uuid',
                '#type': 'type'
              },
              ExpressionAttributeValues: { 
                ':uuid': global.uuid,
                ':type': 'use'
              },
            }
            
            const all_time_access = {
              TableName : 'analytics_dev',
              IndexName: 'uuid-type-index',
              KeyConditionExpression: '#uuid = :uuid AND #type = :type',
              ExpressionAttributeNames: { 
                '#uuid': 'uuid',
                '#type': 'type'
              },
              ExpressionAttributeValues: { 
                ':uuid': global.uuid,
                ':type': 'access',
              },
            }
            
            //Todo: convert 'access' and 'use' to coded values so we can use BETWEEN type1 AND type2
            //https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Query.html#Query.FilterExpression
            const previous_30_days_use = {
              TableName : 'analytics_dev',
              IndexName: 'uuid-type-index',
              KeyConditionExpression: '#uuid = :uuid AND #type = :type',
              FilterExpression: "#datetime >= :date",
              ExpressionAttributeNames: { 
                '#uuid': 'uuid',
                '#type': 'type',
                '#datetime' : 'datetime'
              },
              ExpressionAttributeValues: { 
                ':uuid': global.uuid,
                ':type': 'use',
                ':date': thirty_days_ago_datetime_locale
              },
            }
            
            const previous_30_days_access = {
              TableName : 'analytics_dev',
              IndexName: 'uuid-type-index',
              KeyConditionExpression: '#uuid = :uuid AND #type = :type',
              FilterExpression: "#datetime >= :date",
              ExpressionAttributeNames: { 
                '#uuid': 'uuid',
                '#type': 'type',
                '#datetime' : 'datetime'
              },
              ExpressionAttributeValues: { 
                ':uuid': global.uuid,
                ':type': 'access',
                ':date': thirty_days_ago_datetime_locale
              },
            }
            
            const all_time_use_data = await docClient.query(all_time_use).promise()
            const all_time_access_data = await docClient.query(all_time_access).promise()
            
            const previous_30_days_use_data = await docClient.query(previous_30_days_use).promise()
            const previous_30_days_access_data = await docClient.query(previous_30_days_access).promise()
            
            var all_time = all_time_use_data.Count + all_time_access_data.Count
            var thirty_day = previous_30_days_use_data.Count + previous_30_days_access_data.Count
            
            global.results = '{ "all": ' + all_time + ', "30": ' + thirty_day + ' }';
            
            resolve();
        
          });
        
}


 function eleven() {
      
        return new Promise(async function(resolve) { 
            
            let sqlQuery;
            
            if (typeof global.theme !== 'undefined') {
            sqlQuery = "SELECT COUNT(*) AS total, COUNT(DISTINCT(SPLIT_PART(COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.en') AS VARCHAR), 'N/A'), ';', 2))) AS organization FROM metadata WHERE " + global.theme_search + "";
            } else {
            sqlQuery = "SELECT COUNT(*) AS total, COUNT(DISTINCT(SPLIT_PART(COALESCE(CAST(json_extract(json_array_get(json_parse(features_properties_contact), 0), '$.organisation.en') AS VARCHAR), 'N/A'), ';', 2))) AS organization FROM metadata";    
            }
            
            await athenaExpress1.query(sqlQuery)
            .then(function (response){ 

                global.results = response;
                
            });
            
            resolve();
            
      });

}


function theme_one() {
    
    return new Promise(resolve => {

    if (typeof global.theme !== 'undefined') {
    
    if (global.theme.includes('administration')) {
        global.admin = "boundaries|planning_cadastre|location";
    } else {
        global.admin = "";
    }
    
    if (global.theme.includes('economy')) {
        global.economy = "economy|farming";
    } else {
        global.economy = "";
    }
    
    if (global.theme.includes('environment')) {
        global.environment = "biota|environment|elevation|inland_waters|oceans|climatologyMeteorologyAtmosphere";
    } else {
        global.environment = "";
    }
    
    if (global.theme.includes('imagery')) {
        global.imagery = "imageryBaseMapsEarthCover";
    } else {
        global.imagery = "";
    }
    
    if (global.theme.includes('infrastructure')) {
        global.infrastructure = "structure|transport|utilitiesCommunication";
    } else {
        global.infrastructure = "";
    }
    
    if (global.theme.includes('science')) {
        global.science = "geoscientificInformation";
    } else {
        global.science = "";
    }
    
    if (global.theme.includes('society')) {
        global.society = "health|society|intelligenceMilitary";
    } else {
        global.society = "";
    }
    
    global.pre_theme_string = global.admin + global.economy + global.environment + global.imagery + global.infrastructure + global.science + global.society;
    //var pre_theme_string_trim = pre_theme_string.slice(0, -1);
    
    if (global.theme.includes('legal')) {
    
        var params = {
            TableName: theme_tableName,
            FilterExpression: "tag = :tag",
            ExpressionAttributeValues: {
                ":tag":{"S":"legal"},
        }};
        
        dynamodb.scan(params, function(err, data) {
        
        if (err) {
            console.log("Error", err);
        } else {
            
            data.Items.forEach(function(result, index, array) {
                
                global.legal_scan_result = result.uuid.S + "|";
                global.legal_scan_results.push(global.legal_scan_result); 
                
            });
            
        }
        
        global.legal_scan_results_string = String(global.legal_scan_results);
        global.legal_1 = global.legal_scan_results_string.replace(/\,/g, '');
        global.legal = global.legal_1.slice(0, -1);
        
        });

    }
    
    if (global.theme.includes('emergency')) {
        
        var params = {
        TableName: theme_tableName,
        FilterExpression: "tag = :tag",
        ExpressionAttributeValues: {
            ":tag":{"S":"emergency"},
        }};
        
        dynamodb.scan(params, function(err, data) {
        
        if (err) {
            console.log("Error", err);
        } else {
            
            data.Items.forEach(function(result, index, array) {
                
                global.emergency_scan_result = result.uuid.S + "|";
                global.emergency_scan_results.push(global.emergency_scan_result); 
                
            });
            
        }
        
        global.emergency_scan_results_string = String(global.emergency_scan_results);
        global.emergency_1 = global.emergency_scan_results_string.replace(/\,/g, '');
        global.emergency = global.emergency_1.slice(0, -1);
        
        });
        
    }
    
    if (global.theme.includes('foundational')) {

        var params = {
            TableName: "foundational",
            FilterExpression: "tag = :tag",
            ExpressionAttributeValues: {
                ":tag":{"S":"foundational"},
        }};

        dynamodb.scan(params, function(err, data) {

        if (err) {
            console.log("Error", err);
        } else {

            data.Items.forEach(function(result, index, array) {

                global.foundational_scan_result = result.uuid.S + "|";
                global.foundational_scan_results.push(global.foundational_scan_result); 

            });
        
        }

            global.foundational_scan_results_string = String(global.foundational_scan_results);
            global.foundational_1 = global.foundational_scan_results_string.replace(/\,/g, '');
            global.foundational = global.foundational_1.slice(0, -1);

        });
        
    }

    }   

    resolve();
    });
}

function theme_two() {
    
    if (typeof global.theme !== 'undefined') {
        
    var pre_tag_theme_string = global.legal + global.emergency + global.foundational;
    var pre_tag_theme_string_trim = String(pre_tag_theme_string).slice(0, -1);
    
    
    if ( global.theme.includes('administration')||global.theme.includes('economy')||global.theme.includes('environment')||global.theme.includes('imagery')||global.theme.includes('infrastructure')||global.theme.includes('science')||global.theme.includes('society') ) {
        
        if ( !global.theme.includes('legal')||!global.theme.includes('emergency')||!global.theme.includes('foundational') ) {
            
            global.theme_search = "regexp_like(features_properties_topicCategory, '" + global.pre_theme_string + "')";
            
        } else {
            
            global.theme_search = "regexp_like(features_properties_topicCategory, '" + global.pre_theme_string + "') AND regexp_like(features_properties_id, '" + pre_tag_theme_string_trim + "')";
             
        }
    
    } 
    
    if ( global.theme.includes('legal')||global.theme.includes('emergency')||global.theme.includes('foundational') ) { 
        
        if ( !global.theme.includes('administration')||!global.theme.includes('economy')||!global.theme.includes('environment')||!global.theme.includes('imagery')||!global.theme.includes('infrastructure')||!global.theme.includes('science')||!global.theme.includes('society') ) {
        
            global.theme_search = "regexp_like(features_properties_id, '" + pre_tag_theme_string_trim + "')";
    
        } else {
            
            global.theme_search = "regexp_like(features_properties_topicCategory, '" + global.pre_theme_string + "') AND regexp_like(features_properties_id, '" + pre_tag_theme_string_trim + "')";
        }
    }}
}


function time() {
        return new Promise(resolve => {
        setTimeout(() => {
            //console.log(global.pre_results);
        resolve();
        }, 500) ;
    });
    } 

if (query_id === '1') {
    
    await one();
    
}
    
if (query_id === '2') {
    
    await two();
    
}
    
if (query_id === '3') {

    await three();
    
}

if (query_id === '4') {
    
    await four_one();
    await time();
    await four_two();
    
}

if (query_id === '5') {
    
    await five_one();
    await time();
    await five_two();
    
}

if (query_id === '6') {
    
    await six();
    
}
 
if (query_id === '7') {
    
    await seven();
    
}

if (query_id === '8') {
    
    await theme_one();
    await time();
    await theme_two();
    await eight_one();
    await eight_two();
    await eight_three();
    
}

if (query_id === '9') {
    
    await nine_one();
    await nine_two();
    await nine_three();
    
}

if (query_id === '10') {
    
    await ten();
    
}

if (query_id === '11') {
    
    await theme_one();
    await time();
    await theme_two();
    await eleven();
    
}
        
    //console.log(results);
    
    let results = global.results;
    //console.log(global.response);
    
    callback(null, results);
};